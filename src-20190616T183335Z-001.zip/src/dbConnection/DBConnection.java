 

package dbConnection;

import java.sql.Connection;
import java.sql.DriverManager;



public class DBConnection {
    
        
   public static Connection con() throws Exception{
        
        Class.forName("com.mysql.jdbc.Driver");
        Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/buono", "root", "root");
        return c;  
    }
    
}
