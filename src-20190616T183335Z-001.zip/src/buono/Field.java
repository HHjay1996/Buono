/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package buono;

/**
 *
 * @author PRADEEP
 */
public class Field {
    
    private String item,qty,price;
    

    Field(String item, String qty,String price) {
        this.item = item;
        this.price = price;
        this.qty = qty;
        
    }

    /**
     * @return the item
     */
    public String getItem() {
        return item;
    }

    /**
     * @return the price
     */
    public String getPrice() {
        return price;
    }
    /**
     * @return the qty
     */
    public String getQty() {
        return qty;
    }
    
}
