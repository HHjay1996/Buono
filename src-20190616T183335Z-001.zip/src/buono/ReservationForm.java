/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package buono;

import dbConnection.DBConnection;
import gnu.io.CommPortIdentifier;
import gnu.io.PortInUseException;
import gnu.io.SerialPort;
import gnu.io.UnsupportedCommOperationException;
import java.awt.Color;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

/**
 *
 * @author Niro
 */
public class ReservationForm extends javax.swing.JFrame {
    
     CommPortIdentifier comport;
    final String porName = "COM5";
    OutputStream output;
    
        
    /**
     * Creates new form ReservationForm
     */
    public ReservationForm() {
        initComponents();
        makeConection();
        mckeSerialConnection();;
        IDgen();
        Combo();
         
        
       
        
   
    }
    
     void IDgen()
    {
        try {
            Connection c= DBConnection.con();
            Statement s=c.createStatement();
             ResultSet rs = s.executeQuery("SELECT * FROM reservation");
            int xx=0;
            while(rs.next())
            {
              xx++;  
            }
            rid.setText(rid.getText()+xx);
            
            
        } catch (Exception e) {
        }
    }
     
     void Combo()
     {
         try {
              Connection c;
            c = DBConnection.con();
            
             PreparedStatement ps = c.prepareStatement("select Tid from restables ");
        
        
        ResultSet rs = ps.executeQuery(); 
         while(rs.next())
            {
                
                cmbtbl.addItem(rs.getString("Tid")); 
            }
 
         } catch (Exception e) {
         }
     }
     
 /*    void DateDis()
     {
      
         try {
             Connection c;
            c = DBConnection.con();
            PreparedStatement ps = c.prepareStatement("select date from events ");
      
        ResultSet rs = ps.executeQuery(); 
         while(rs.next())
            {
                
                dd.disable(rs.getString("date"));
            }
             
             
         } catch (Exception e) {
         }
     }
     */
     void makeConection() {
        CommPortIdentifier port = null;
        Enumeration portlist = CommPortIdentifier.getPortIdentifiers();
        while (portlist.hasMoreElements()) {
            port = (CommPortIdentifier) portlist.nextElement();
        }
        try {
            if (port.getName().equals(porName)) {
                comport=port;
            } else {
                JOptionPane.showMessageDialog(null, "Arduino is Not Connected to COM3 Port",null,JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            
            JOptionPane.showMessageDialog(null, "Arduino bord is not Connected to pc",null,JOptionPane.INFORMATION_MESSAGE);
            System.exit(0);
        }

        
    }
   void mckeSerialConnection(){
   
       try {
            SerialPort sport=(SerialPort) comport.open(this.getClass().getName(),2000);
            sport.setSerialPortParams(9600,SerialPort.DATABITS_8,SerialPort.STOPBITS_1,SerialPort.PARITY_NONE);
            output=sport.getOutputStream();
       } catch (PortInUseException e) {
            JOptionPane.showMessageDialog(null, comport.getName()+"Por is In use",null,JOptionPane.INFORMATION_MESSAGE);
       }
       catch (UnsupportedCommOperationException ee) {
            JOptionPane.showMessageDialog(null, "Device is unsupported to communicate",null,JOptionPane.INFORMATION_MESSAGE);
       }
       catch(IOException i){
        JOptionPane.showMessageDialog(null, "Device is unsupported to communicate",null,JOptionPane.INFORMATION_MESSAGE);
       }
   
   }
   
   void SendData(String s){
       try {
           output.write(s.getBytes());
       } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"I/O error occurs",null,JOptionPane.INFORMATION_MESSAGE);
       }
   
   }

 /*     public  void setSelectableDateRange(Date min, Date max)
    {
        dd.setSelectableDateRange (min, max);
        dd.setSelectableDateRange (dd.getMinSelectableDate (),
                                           dd.getMaxSelectableDate ());
    }

    public  void setMaxSelectableDate(Date max)
    {
        dd.setMaxSelectableDate (max);
        dd.setMaxSelectableDate (max);
    }

    public  void setMinSelectableDate(Date min)
    {
        dd.setMinSelectableDate (min);
        dd.setMinSelectableDate (min);
    }
     public  Date getMaxSelectableDate()
    {
        
        return dd.getMaxSelectableDate ();
    }
     public  Date getMinSelectableDate()
    {
        return dd.getMinSelectableDate ();
    }
     */
     

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDesktopPane1 = new javax.swing.JDesktopPane();
        jPanel2 = new javax.swing.JPanel();
        tbtn1 = new javax.swing.JButton();
        tbtn5 = new javax.swing.JButton();
        tbtn2 = new javax.swing.JButton();
        tbtn3 = new javax.swing.JButton();
        tbtn4 = new javax.swing.JButton();
        tbtn6 = new javax.swing.JButton();
        tbtn7 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        displayD = new javax.swing.JLabel();
        displayT = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        phone = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        rid = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        guests = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        cmbtbl = new javax.swing.JComboBox<>();
        jButton20 = new javax.swing.JButton();
        jButton19 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        time = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        fat = new javax.swing.JButton();
        dd = new com.toedter.calendar.JDateChooser();
        jLabel6 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        re = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        searchphone = new javax.swing.JTextField();
        jButton13 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jDesktopPane1.setAutoscrolls(true);

        tbtn1.setBackground(new java.awt.Color(0, 153, 102));
        tbtn1.setText("Table01");
        tbtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbtn1ActionPerformed(evt);
            }
        });

        tbtn5.setBackground(new java.awt.Color(0, 153, 102));
        tbtn5.setText("TABLE 05");
        tbtn5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbtn5ActionPerformed(evt);
            }
        });

        tbtn2.setBackground(new java.awt.Color(0, 153, 102));
        tbtn2.setText("TABLE 02");

        tbtn3.setBackground(new java.awt.Color(0, 153, 102));
        tbtn3.setText("TABLE 03");

        tbtn4.setBackground(new java.awt.Color(0, 153, 102));
        tbtn4.setText("TABLE 04");

        tbtn6.setBackground(new java.awt.Color(0, 153, 102));
        tbtn6.setText("TABLE 06");

        tbtn7.setBackground(new java.awt.Color(0, 153, 102));
        tbtn7.setText("TABLE 07");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(73, 73, 73))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(tbtn6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(tbtn7, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(tbtn5, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(tbtn1, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(tbtn3, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tbtn4, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tbtn2))
                            .addGap(79, 79, 79)))
                    .addComponent(displayT, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(displayD, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 57, Short.MAX_VALUE))
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {tbtn1, tbtn2, tbtn3, tbtn4, tbtn5, tbtn6, tbtn7});

        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(displayD, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(displayT, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addComponent(tbtn1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tbtn5, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tbtn2, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tbtn6, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tbtn3, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tbtn7, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tbtn4, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {tbtn1, tbtn2, tbtn3, tbtn4, tbtn5, tbtn6, tbtn7});

        jLabel2.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jLabel2.setText("Name");

        jLabel3.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jLabel3.setText("Phone Number");

        name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameActionPerformed(evt);
            }
        });
        name.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                nameKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                nameKeyTyped(evt);
            }
        });

        phone.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                phoneKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                phoneKeyTyped(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jLabel4.setText("Reservation ID");

        rid.setEditable(false);
        rid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ridActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jLabel5.setText("Number of Guests");

        guests.setForeground(new java.awt.Color(51, 51, 51));
        guests.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08" }));
        guests.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guestsActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jLabel9.setText("Table Number");

        cmbtbl.addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentRemoved(java.awt.event.ContainerEvent evt) {
                cmbtblComponentRemoved(evt);
            }
        });
        cmbtbl.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cmbtblItemStateChanged(evt);
            }
        });
        cmbtbl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbtblActionPerformed(evt);
            }
        });

        jButton20.setBackground(new java.awt.Color(51, 51, 51));
        jButton20.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jButton20.setForeground(new java.awt.Color(255, 255, 255));
        jButton20.setText("CANCEL");
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });

        jButton19.setBackground(new java.awt.Color(51, 51, 51));
        jButton19.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jButton19.setForeground(new java.awt.Color(255, 255, 255));
        jButton19.setText("EDIT");
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(51, 51, 51));
        jButton4.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("SAVE");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        time.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "8.00am-12.00noon", "12.00noon-4.00pm", "4.00pm-8.00pm" }));
        time.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                timeActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jLabel7.setText("Time Slot");

        fat.setText("find a table");
        fat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fatActionPerformed(evt);
            }
        });

        dd.setAutoscrolls(true);
        dd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                ddMouseReleased(evt);
            }
        });
        dd.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ddKeyReleased(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jLabel6.setText("Date");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dd, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fat))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(time, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(18, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dd, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(41, 41, 41))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(fat, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(time, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jButton1.setBackground(new java.awt.Color(51, 51, 51));
        jButton1.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("SEND SMS");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        re.setText("Refresh");
        re.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jLabel5)
                    .addComponent(jLabel4)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(phone, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(guests, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rid, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(71, 71, 71)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addGap(18, 18, 18)
                                .addComponent(cmbtbl, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 90, Short.MAX_VALUE))
                    .addComponent(re, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton19, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton20, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(5, 5, 5))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(rid)
                                .addGap(16, 16, 16)))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(phone, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(26, 26, 26)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(55, 55, 55))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(re)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(16, 16, 16)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cmbtbl, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel5)
                        .addComponent(guests, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(55, 55, 55)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton20)
                    .addComponent(jButton19)
                    .addComponent(jButton4))
                .addGap(9, 9, 9))
        );

        jLabel1.setFont(new java.awt.Font("Rockwell Condensed", 1, 56)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 51, 0));
        jLabel1.setText("Reservation Details");

        jLabel10.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jLabel10.setText("Search by Phone Number or ID");

        jButton13.setText("GO");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel10)
                .addGap(18, 18, 18)
                .addComponent(searchphone, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton13)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchphone, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(57, Short.MAX_VALUE))
        );

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/buono/img/Actions-home-icon.png"))); // NOI18N

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/buono/img/Go-back-icon.png"))); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jDesktopPane1.setLayer(jPanel2, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(jPanel3, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(jLabel1, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(jPanel4, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(jButton2, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jDesktopPane1.setLayer(jButton3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jDesktopPane1Layout.createSequentialGroup()
                        .addGroup(jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 440, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(25, 25, 25)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 73, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jDesktopPane1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jButton2, jButton3});

        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jDesktopPane1Layout.createSequentialGroup()
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(36, 36, 36))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jDesktopPane1Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(63, Short.MAX_VALUE))
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jDesktopPane1Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {jButton2, jButton3});

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
  
        try {
             Connection c = DBConnection.con();
            Statement s= c.createStatement();
            
            ResultSet rs = s.executeQuery("SELECT * FROM reservation WHERE phone='"+searchphone.getText().trim()+"' OR rid='"+searchphone.getText().trim()+"'  ");
            
            while(rs.next())
            {
                String id1 = rs.getString("rid");
                rid.setText(id1);
                String name1 = rs.getString("name"); 
                name.setText(name1);
                
                String phone1 = rs.getString("phone");
                phone.setText(phone1);
                
                String guests1 = rs.getString("guests");
                guests.setSelectedItem(guests1);
                
               // String date1 = rs.getDate("date");
                dd.setDate(rs.getDate("date"));
                
                String time1 = rs.getString("time");
                time.setSelectedItem(time1);
                
                String table1 = rs.getString("ctable");
                cmbtbl.setSelectedItem(table1);
            }
            
            
        } catch (Exception e) {
            e.printStackTrace();
           
        }
        
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed

        /*  SearchReservations sr1= new SearchReservations();
        sr1.setVisible(true);
        dispose(); */
        
        String ph=phone.getText();
        
        String pattern = "yyyy-MM-dd";
         SimpleDateFormat sdf = new SimpleDateFormat(pattern);
            String d =sdf.format(dd.getDate());
             System.out.println(d);
 
 
        try {
            
            if(!ph.matches("^[0-9]{10}"))
            {
                JOptionPane.showMessageDialog(null,"Enter a valid phone number");
                
            }
             Date date= new Date();
            // Calendar c = Calendar.getInstance();
            
             
        
       if(dd.getDate().before(date))
        {
             JOptionPane.showMessageDialog(null,"Invalid date entry" );
        }
     //  
           //  =zc.add(Calendar.DATE, 14);
             
            // if(dd.getDate().after(c))
   
            else{

            Connection c = DBConnection.con();
            Statement s= c.createStatement();

            //      SimpleDateFormat d = new SimpleDateFormat("yyyy-MM-dd");
            //    String date1 =d.format(date.getSelectedDate().getTime());

            s.executeUpdate("INSERT INTO reservation VALUES('"+new Integer(rid.getText())+"' , '"+name.getText()+"' , '"+phone.getText()+"' , '"+guests.getSelectedItem().toString()+"' , '"+d+"' , '"+time.getSelectedItem().toString()+"' , '"+cmbtbl.getSelectedItem().toString() +"' )");

            JOptionPane.showMessageDialog(null,"TABLE RESERVED!" );
            
            
            
        
        
        if("Table01".equals(cmbtbl.getSelectedItem())){
                    tbtn1.setBackground(Color.red);
                }
                
                if("Table02".equals(cmbtbl.getSelectedItem())){
                    tbtn2.setBackground(Color.red);
                }
                if("Table03".equals(cmbtbl.getSelectedItem())){
                    tbtn3.setBackground(Color.red);
                }
                if("Table04".equals(cmbtbl.getSelectedItem())){
                    tbtn4.setBackground(Color.red);
                }
                if("Table05".equals(cmbtbl.getSelectedItem())){
                    tbtn5.setBackground(Color.red);
                }
                if("Table06".equals(cmbtbl.getSelectedItem())){
                    tbtn6.setBackground(Color.red);
                }
                if("Table07".equals(cmbtbl.getSelectedItem())){
                    tbtn7.setBackground(Color.red);
                }
                
       
            
            }

        } catch (Exception e) {
            e.printStackTrace();

            JOptionPane.showMessageDialog(null, "error");
        }
            
        
          
         
        

    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed

         String pattern = "yyyy-MM-dd";
         SimpleDateFormat sdf = new SimpleDateFormat(pattern);
            String d =sdf.format(dd.getDate());
             System.out.println(d);
        
         try {
            
            Connection c = DBConnection.con();
            Statement s= c.createStatement();
            s.executeUpdate("UPDATE reservation SET name= '"+name.getText()+"' , phone='"+phone.getText()+"' , guests='"+guests.getSelectedItem().toString()+"' , date='d' , time='"+time.getSelectedItem().toString()+"' , table='"+cmbtbl.getSelectedItem().toString()+"' WHERE rid='"+rid.getText()+"'   ");
            JOptionPane.showMessageDialog(null,"EDITED!" );
            
        } catch (Exception e) {
            e.printStackTrace();
            
            JOptionPane.showMessageDialog(null, "error");
        }
        
        
        
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton19ActionPerformed

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
        
         try {
            
            Connection c = DBConnection.con();
            Statement s= c.createStatement();
            s.executeUpdate("DELETE FROM reservation  WHERE rid='"+rid.getText()+"'   ");
            JOptionPane.showMessageDialog(null,"Cancelled!" );
            
        } catch (Exception e) {
            e.printStackTrace();
            
            JOptionPane.showMessageDialog(null, "error");
        }
        
        
        
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton20ActionPerformed

    private void timeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_timeActionPerformed

            // TODO add your handling code here:
    }//GEN-LAST:event_timeActionPerformed

    private void cmbtblActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbtblActionPerformed

        

        // TODO add your handling code here:
    }//GEN-LAST:event_cmbtblActionPerformed

    private void guestsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guestsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_guestsActionPerformed

    private void ridActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ridActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ridActionPerformed

    private void nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nameActionPerformed

    private void reActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reActionPerformed

        

        rid.setText(null);
        name.setText(null);
        phone.setText(null);
        guests.setSelectedItem(null);
        
        
        time.setSelectedItem(null);
        cmbtbl.setSelectedItem(null);
        
        IDgen();
        

        // TODO add your handling code here:
    }//GEN-LAST:event_reActionPerformed

    private void fatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fatActionPerformed

     
        
         String pattern = "yyyy-MM-dd";
         SimpleDateFormat sdf = new SimpleDateFormat(pattern);
            String d =sdf.format(dd.getDate());
             System.out.println(d);
        
             
         Date date= new Date();
        
       if(dd.getDate().before(date))
        {
             JOptionPane.showMessageDialog(null,"Invalid date entry" );
        }
         
        try {
            Connection c;
            c = DBConnection.con();
        
        PreparedStatement ps = c.prepareStatement("select ctable from reservation where date=? AND time=?");
        ps.setString(1, d);
        ps.setString(2, (String) time.getSelectedItem());
        ResultSet rs = ps.executeQuery();   
        
        PreparedStatement ps2 = c.prepareStatement("select booking from events where date=? ");
        ps2.setString(1, d);
        ResultSet rs2 = ps2.executeQuery();
              
        displayD.setText(d);
        displayT.setText((String) time.getSelectedItem());
        
           while(rs.next())
            {  
                cmbtbl.removeItem(rs.getString("ctable")); 
                
               
               
              
                if("Table01".equals(rs.getString("ctable"))){
                    tbtn1.setBackground(Color.red);
                }
                
                if("Table02".equals(rs.getString("ctable"))){
                    tbtn2.setBackground(Color.red);
                }
                if("Table03".equals(rs.getString("ctable"))){
                    tbtn3.setBackground(Color.red);
                }
                if("Table04".equals(rs.getString("ctable"))){
                    tbtn4.setBackground(Color.red);
                }
                if("Table05".equals(rs.getString("ctable"))){
                    tbtn5.setBackground(Color.red);
                }
                if("Table06".equals(rs.getString("ctable"))){
                    tbtn6.setBackground(Color.red);
                }
                if("Table07".equals(rs.getString("ctable"))){
                    tbtn7.setBackground(Color.red);
                }
                
          
             }
            while(rs2.next()){
                
                cmbtbl.removeAllItems();
                
            if("1".equals(rs2.getString("booking")))
                {
                   tbtn1.setBackground(Color.red);
                   tbtn2.setBackground(Color.red);
                   tbtn3.setBackground(Color.red);
                   tbtn4.setBackground(Color.red);
                   tbtn5.setBackground(Color.red);
                   tbtn6.setBackground(Color.red); 
                   tbtn7.setBackground(Color.red);
                   
                   jLabel8.setText("SORRY!");
                   jLabel11.setText("This date is booked for an Event");
                   
                   JOptionPane.showMessageDialog(null,"SORRY! This date is booked for an Event" );
                   
                }
            }

        } catch (Exception ex) {
            Logger.getLogger(ReservationForm.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
            
        
      

        // TODO add your handling code here:
        
        
            
        
      

        // TODO add your handling code here:
    }//GEN-LAST:event_fatActionPerformed

    private void phoneKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_phoneKeyTyped

        // TODO add your handling code here:
    }//GEN-LAST:event_phoneKeyTyped

    private void nameKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nameKeyTyped

   /*      char c = evt.getKeyChar();
       
       if(!(Character.isDigit(c)||(c==KeyEvent.VK_BACKSPACE)||(c==KeyEvent.VK_DELETE) )  )
       {
           JOptionPane.showMessageDialog(null, "enter a valid name!");
           evt.consume();
       }

        */
        // TODO add your handling code here:
    }//GEN-LAST:event_nameKeyTyped

    private void cmbtblItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cmbtblItemStateChanged

     /*   table.removeAllItems();
        
        try {
            
            Connection c = DBConnection.con();
            Statement s= c.createStatement();
            ResultSet rs = s.executeUpdate("SELECT * FROM reservation WHERE date='d' AND time='\"+time.getSelectedItem()+\"' \");
            
            
            
            
        } catch (Exception e) {
        }
*/
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbtblItemStateChanged

    private void tbtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbtn1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tbtn1ActionPerformed

    private void tbtn5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbtn5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tbtn5ActionPerformed

    private void cmbtblComponentRemoved(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_cmbtblComponentRemoved

        
        
        

        // TODO add your handling code here:
    }//GEN-LAST:event_cmbtblComponentRemoved

    private void ddMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ddMouseReleased

        

        // TODO add your handling code here:
    }//GEN-LAST:event_ddMouseReleased

    private void nameKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nameKeyReleased

        




        // TODO add your handling code here:
    }//GEN-LAST:event_nameKeyReleased

    private void phoneKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_phoneKeyReleased


         try {
            Connection c = DBConnection.con();
            Statement s=c.createStatement();
            ResultSet rs=s.executeQuery("SELECT name FROM customer WHERE mobile='"+phone.getText().trim()+"' ");
            
            while(rs.next())
            {
                
                        name.setText(rs.getString("name"));
               
            }

        } catch (Exception e) {
            e.printStackTrace();
        }


        // TODO add your handling code here:
    }//GEN-LAST:event_phoneKeyReleased

    private void ddKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ddKeyReleased

         String pattern = "yyyy-MM-dd";
         SimpleDateFormat sdf = new SimpleDateFormat(pattern);
         Date date= new Date();
        
       if(dd.getDate().before(date))
        {
             JOptionPane.showMessageDialog(null,"Invalid date entry" );
        }


        // TODO add your handling code here:
    }//GEN-LAST:event_ddKeyReleased

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        
       SendData("1"+phone.getText().trim()+"Dear customer, We hereby inform you that you have made a reservation on" +dd.getDate()+ "from" +time.getSelectedItem()+". Your Reservation ID :" +rid.getText()+ "Table ID :"+cmbtbl.getSelectedItem()+"     Thank you. Team BUONO");
        
        rid.setText(null);
        name.setText(null);
        phone.setText(null);
        guests.setSelectedItem(null);
        dd.setDate(null);
        time.setSelectedItem(null);
        cmbtbl.setSelectedItem(null);
        
        IDgen();
        

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

          Reservations ab = new Reservations();
        ab.setVisible(true);
        dispose();

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
           for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
              /*  if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }*/
               UIManager.setLookAndFeel("com.jtattoo.plaf.texture.TextureLookAndFeel");
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ReservationForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ReservationForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ReservationForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ReservationForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ReservationForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cmbtbl;
    private com.toedter.calendar.JDateChooser dd;
    private javax.swing.JLabel displayD;
    private javax.swing.JLabel displayT;
    private javax.swing.JButton fat;
    private javax.swing.JComboBox<String> guests;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JTextField name;
    private javax.swing.JTextField phone;
    private javax.swing.JButton re;
    private javax.swing.JTextField rid;
    private javax.swing.JTextField searchphone;
    private javax.swing.JButton tbtn1;
    private javax.swing.JButton tbtn2;
    private javax.swing.JButton tbtn3;
    private javax.swing.JButton tbtn4;
    private javax.swing.JButton tbtn5;
    private javax.swing.JButton tbtn6;
    private javax.swing.JButton tbtn7;
    private javax.swing.JComboBox<String> time;
    // End of variables declaration//GEN-END:variables
}
